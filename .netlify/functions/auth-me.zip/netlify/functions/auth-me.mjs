
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/auth-me.mjs
import jwt from "jsonwebtoken";

// netlify/functions/lib/db.mjs
import pg from "pg";
var { Pool } = pg;
var pool;
function getDb() {
  if (!pool) {
    pool = new Pool({ connectionString: process.env.NETLIFY_DATABASE_URL || process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
  }
  return pool;
}
async function query(text, params) {
  const db = getDb();
  const res = await db.query(text, params);
  return res.rows;
}

// netlify/functions/auth-me.mjs
function verifyToken(req) {
  const token = req.headers.get("authorization")?.replace("Bearer ", "");
  if (!token) return null;
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch {
    return null;
  }
}
var auth_me_default = async (req) => {
  const payload = verifyToken(req);
  if (!payload) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const rows = await query("SELECT id, email, full_name FROM users WHERE id = $1", [payload.userId]);
  return Response.json(rows[0] || null);
};
var config = { path: "/api/auth/me" };
export {
  config,
  auth_me_default as default,
  verifyToken
};
