
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/auth-me.mjs
import jwt from "jsonwebtoken";

// netlify/functions/lib/db.mjs
import pg from "pg";
var { Pool } = pg;
var pool;
function getDb() {
  if (!pool) {
    pool = new Pool({ connectionString: process.env.NETLIFY_DATABASE_URL || process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
  }
  return pool;
}
async function query(text, params) {
  const db = getDb();
  const res = await db.query(text, params);
  return res.rows;
}

// netlify/functions/auth-me.mjs
function verifyToken(req) {
  const token = req.headers.get("authorization")?.replace("Bearer ", "");
  if (!token) return null;
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch {
    return null;
  }
}

// netlify/functions/orgs.mjs
var orgs_default = async (req) => {
  if (!verifyToken(req)) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const url = new URL(req.url);
  const orgId = url.searchParams.get("org_id");
  if (orgId) {
    const rows = await query(`
      SELECT o.*,
        COALESCE(p.full_name, p.description) AS parent_name,
        ot.name AS org_type, ot.category AS org_category
      FROM orgs o
      LEFT JOIN orgs p ON o.parent_id = p.id
      LEFT JOIN org_types ot ON o.org_type_id = ot.id
      WHERE o.id = $1`, [orgId]);
    if (!rows[0]) return Response.json({ error: "Not found" }, { status: 404 });
    const org = rows[0];
    const children = await query(
      `SELECT id, COALESCE(abbreviation, sub) AS abbr, COALESCE(full_name, description) AS name, branch
       FROM orgs WHERE parent_id = $1 ORDER BY COALESCE(abbreviation, sub)`,
      [orgId]
    );
    const contracts = await query(`
      SELECT id, title, type, agency, sub_agency, contracting_office, value, award_amt,
             posted_date, deadline, poc, poc_email, recipient, sol_num, description, notice_type, sam_url
      FROM contracts
      WHERE org_id = $1 OR org_id_level_1 = $1 OR org_id_level_2 = $1 OR org_id_level_3 = $1
      ORDER BY posted_date DESC NULLS LAST LIMIT 50`, [orgId]);
    org.children = children;
    org.live_contracts = contracts;
    return Response.json(org);
  }
  const branch = url.searchParams.get("branch");
  let orgs;
  if (branch && branch.toLowerCase() !== "all") {
    orgs = await query(`SELECT * FROM orgs WHERE LOWER(branch) = LOWER($1) ORDER BY COALESCE(full_name, description)`, [branch]);
  } else {
    orgs = await query(`SELECT * FROM orgs ORDER BY COALESCE(full_name, description) LIMIT 600`);
  }
  return Response.json(orgs);
};
var config = { path: "/api/orgs" };
export {
  config,
  orgs_default as default
};
