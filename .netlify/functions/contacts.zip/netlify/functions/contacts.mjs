
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/auth-me.mjs
import jwt from "jsonwebtoken";

// netlify/functions/lib/db.mjs
import pg from "pg";
var { Pool } = pg;
var pool;
function getDb() {
  if (!pool) {
    pool = new Pool({ connectionString: process.env.NETLIFY_DATABASE_URL || process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
  }
  return pool;
}
async function query(text, params) {
  const db = getDb();
  const res = await db.query(text, params);
  return res.rows;
}

// netlify/functions/auth-me.mjs
function verifyToken(req) {
  const token = req.headers.get("authorization")?.replace("Bearer ", "");
  if (!token) return null;
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch {
    return null;
  }
}

// netlify/functions/contacts.mjs
var contacts_default = async (req) => {
  if (!verifyToken(req)) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const url = new URL(req.url);
  const page = Math.max(1, parseInt(url.searchParams.get("page") || "1"));
  const per = 20;
  const offset = (page - 1) * per;
  const q = url.searchParams.get("q") || "";
  const orgId = url.searchParams.get("org_id") || "";
  const sort = url.searchParams.get("sort") || "name";
  const orderMap = {
    hierarchy: "c.hierarchy_order ASC NULLS LAST, c.name ASC",
    name: "c.name ASC NULLS LAST",
    name_desc: "c.name DESC NULLS LAST"
  };
  const orderBy = orderMap[sort] || orderMap.name;
  const conditions = [];
  const params = [];
  if (q) {
    params.push(`%${q.toLowerCase()}%`, `%${q.toLowerCase()}%`, `%${q.toLowerCase()}%`);
    conditions.push(`(LOWER(c.name) LIKE $${params.length - 2} OR LOWER(c.email) LIKE $${params.length - 1} OR LOWER(c.org_full) LIKE $${params.length})`);
  }
  if (orgId) {
    params.push(orgId);
    conditions.push(`c.org_id = $${params.length}`);
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  const countRows = await query(`SELECT COUNT(*) as count FROM contacts c ${where}`, params);
  const rows = await query(
    `SELECT c.id, c.name, c.title, c.email, c.phone, c.org_id, c.org_full FROM contacts c ${where} ORDER BY ${orderBy} LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
    [...params, per, offset]
  );
  return Response.json({ contacts: rows, total: parseInt(countRows[0].count), page, per });
};
var config = { path: "/api/contacts" };
export {
  config,
  contacts_default as default
};
