
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/auth-register.mjs
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

// netlify/functions/lib/db.mjs
import pg from "pg";
var { Pool } = pg;
var pool;
function getDb() {
  if (!pool) {
    pool = new Pool({ connectionString: process.env.NETLIFY_DATABASE_URL || process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
  }
  return pool;
}
async function query(text, params) {
  const db = getDb();
  const res = await db.query(text, params);
  return res.rows;
}

// netlify/functions/auth-register.mjs
var auth_register_default = async (req) => {
  try {
    const { email, password, full_name } = await req.json();
    if (!email || !password) return Response.json({ error: "Email and password required" }, { status: 400 });
    const existing = await query("SELECT id FROM users WHERE email = $1", [email]);
    if (existing.length) return Response.json({ error: "Account already exists" }, { status: 409 });
    const hash = await bcrypt.hash(password, 10);
    const rows = await query(
      "INSERT INTO users (email, password_hash, full_name, created_at) VALUES ($1, $2, $3, NOW()) RETURNING id, email, full_name",
      [email, hash, full_name || email.split("@")[0]]
    );
    const user = rows[0];
    const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, { expiresIn: "7d" });
    return Response.json({ token, user });
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
};
var config = { path: "/api/auth/register" };
export {
  config,
  auth_register_default as default
};
