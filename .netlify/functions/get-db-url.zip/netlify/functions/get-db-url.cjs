"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/get-db-url.ts
var get_db_url_exports = {};
__export(get_db_url_exports, {
  default: () => handler
});
module.exports = __toCommonJS(get_db_url_exports);
async function handler(_req) {
  const url = process.env.NETLIFY_DB_URL ?? "(not set)";
  const masked = url.replace(/:\/\/[^@]+@/, "://***@");
  return Response.json({ NETLIFY_DB_URL: masked, full: url });
}
