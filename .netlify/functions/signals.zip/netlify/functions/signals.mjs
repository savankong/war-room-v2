
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/auth-me.mjs
import jwt from "jsonwebtoken";

// netlify/functions/lib/db.mjs
import pg from "pg";
var { Pool } = pg;
var pool;
function getDb() {
  if (!pool) {
    pool = new Pool({ connectionString: process.env.NETLIFY_DATABASE_URL || process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
  }
  return pool;
}
async function query(text, params) {
  const db = getDb();
  const res = await db.query(text, params);
  return res.rows;
}

// netlify/functions/auth-me.mjs
function verifyToken(req) {
  const token = req.headers.get("authorization")?.replace("Bearer ", "");
  if (!token) return null;
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch {
    return null;
  }
}

// netlify/functions/signals.mjs
var signals_default = async (req) => {
  if (!verifyToken(req)) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const url = new URL(req.url);
  const page = Math.max(1, parseInt(url.searchParams.get("page") || "1"));
  const per = Math.min(200, parseInt(url.searchParams.get("per") || "50"));
  const offset = (page - 1) * per;
  const countRows = await query("SELECT COUNT(*) as count FROM contracts");
  const rows = await query(
    `SELECT id, title, type, agency, sub_agency, contracting_office, value, award_amt,
            posted_date, deadline, poc, poc_email, recipient, sol_num, set_aside, naics,
            description
     FROM contracts ORDER BY posted_date DESC NULLS LAST LIMIT $1 OFFSET $2`,
    [per, offset]
  );
  return Response.json({ signals: rows, total: parseInt(countRows[0].count), page, per });
};
var config = { path: "/api/signals" };
export {
  config,
  signals_default as default
};
