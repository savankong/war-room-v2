"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/seed-orgs.ts
var seed_orgs_exports = {};
__export(seed_orgs_exports, {
  default: () => handler
});
module.exports = __toCommonJS(seed_orgs_exports);
var import_database = require("@netlify/database");
var CSV = `Level,Organization,Parent_Organization,Leader_Name,Leader_Title,Service_Branch,Location,Description
1,Department of War,Executive Branch,Pete Hegseth,Secretary of War,All,Pentagon Arlington VA,Cabinet-level department responsible for national defense renamed from Department of Defense in 2025
1,Office of the Secretary of War,Department of War,Pete Hegseth,Secretary of War,All,Pentagon,Top civilian leadership overseeing all DoW operations
1,Office of Inspector General,OSW,Platte Moring,Inspector General,All,Pentagon,Independent oversight of DoW programs and operations
1,Office of Legislative Affairs,OSW,Macon Dane Hughes,Assistant Secretary for Legislative Affairs,All,Pentagon,Manages DoW relations with Congress
1,Washington Headquarters Services,OSW,Regina F. Meiners,Director,All,Alexandria VA,Provides administrative support to OSW
1,Joint Chiefs of Staff,OSW,GEN Dan Caine,Chairman,All,Pentagon,Principal military advisors to President SecWar and NSC
2,Under Secretary for Acquisition and Sustainment,OSW,Michael Duffey,Under Secretary,All,Pentagon,Oversees all DoW acquisition and sustainment activities
2,Under Secretary for Research and Engineering,OSW,Emil Michael,Under Secretary and DoW CTO,All,Pentagon,Oversees DoW research development and engineering
2,Under Secretary for Policy,OSW,Elbridge Colby,Under Secretary,All,Pentagon,Oversees DoW policy formulation
2,Under Secretary for Intelligence and Security,OSW,Bradley Hansell,Under Secretary,All,Pentagon,Oversees defense intelligence and security enterprise
2,Under Secretary for Personnel and Readiness,OSW,Anthony Tata,Under Secretary,All,Pentagon,Manages DoW human resources and readiness
2,Under Secretary Comptroller CFO,OSW,Jules W. Hurst III,Under Secretary and CFO,All,Pentagon,Oversees DoW budget and financial management
2,Cost Assessment and Program Evaluation CAPE,OSW,Michael Payne,Acting Director,All,Pentagon,Provides cost analysis and program evaluation
2,DoW Chief Information Officer,OSW,Kirsten Davies,DoW CIO,All,Pentagon,Chief information officer for entire DoW
2,Joint Staff J1 Manpower,Joint Chiefs,MG Paige M. Jennings,Director,All,Pentagon,Manpower and personnel for joint operations
2,Joint Staff J2 Intelligence,Joint Chiefs,VADM Thomas M. Henderschedt,Director,All,Pentagon,Intelligence for joint operations
2,Joint Staff J3 Operations,Joint Chiefs,LTG David L. Odom,Director,All,Pentagon,Joint operations directorate
2,Joint Staff J4 Logistics,Joint Chiefs,LTG Keith D. Reventlow,Director,All,Pentagon,Joint logistics directorate
2,Joint Staff J5 Strategy Plans Policy,Joint Chiefs,LTG Brett G. Sylvia,Director,All,Pentagon,Strategic plans and policy
2,Joint Staff J6 C4 Cyber,Joint Chiefs,LTG David T. Isaacson,Director and CIO,All,Pentagon,Command control communications computers and cyber
2,Joint Staff J7 Joint Force Development,Joint Chiefs,LTG Stephen E. Liszewski,Director,All,Pentagon,Joint force training and development
2,Joint Staff J8 Force Structure,Joint Chiefs,LTG Steven Whitney,Director,All,Pentagon,Force structure and resource assessment
3,JIATF-401 Counter-UAS,Direct Reporting to DepSecWar,BG Matt Ross,Director,DoW,Fort Liberty NC,Lead organization for counter-small UAS development
3,Golden Dome Missile Defense,Direct Reporting to DepSecWar,GEN Michael A. Guetlein,Director DRPM,DoW,Peterson SFB CO,Space-based missile defense shield
3,Submarine DRPM,Direct Reporting to DepSecWar,VADM Robert M. Gaucher,Director DRPM,DoW,Washington Navy Yard DC,Oversees Virginia and Columbia-class submarine construction
3,Critical Major Weapon Systems DRPM,Direct Reporting to DepSecWar,GEN Dale R. White,Director DRPM,DoW,Multiple Locations,Oversees B-21 F-47 Sentinel VC-25B Minuteman III
3,Special Access Programs Central Office SAPCO,Direct Reporting to DepSecWar,MG David W. Abba,Director,DoW,Pentagon,Manages DoW special access programs
3,Economic Defense Unit,OUSD R&E,George K. Kollitides II,Head,DoW,Pentagon,Leads economic competition and national security
3,Office of Strategic Capital,OUSD R&E,David Lorch,Director,DoW,Pentagon,Provides debt investment and equipment financing
3,Defense Innovation Unit DIU,OUSD R&E,Owen West,Director,DoW,Mountain View CA,Field commercial technology to military at commercial speeds
3,DARPA,OUSD R&E,Stephen Winchell,Director,DoW,Arlington VA,Creates and prevents strategic surprise through technology
3,Strategic Capabilities Office SCO,OUSD R&E,Jay Dryer,Director,DoW,Pentagon,Identifies disruptive applications of existing systems
3,Missile Defense Agency MDA,OUSD R&E,LTG Heath Collins,Director,DoW,Fort Belvoir VA,Develops and fields missile defense systems
3,Defense Innovation Fellows,OUSD R&E,Various,Program,DoW,Multiple,Trains innovators to work with DoW
4,Department of the Army,OSW,Daniel P. Driscoll,Secretary of the Army,Army,Pentagon,Military department responsible for land warfare
4,Department of the Navy,OSW,Hung Cao,Acting Secretary,DoN,Pentagon,Military department for Navy and Marine Corps
4,Department of the Air Force,OSW,Dr. Troy E. Meink,Secretary of the Air Force,Air Force/Space Force,Pentagon,Military department for Air Force and Space Force
4,United States Coast Guard,Department of Homeland Security,ADM Kevin Lunday,Commandant,Coast Guard,Washington DC,Part of DHS not DoW but works closely with DoW
4,Combatant Commands,OSW,Varies,Varies,All,Worldwide,11 commands that conduct military operations
6,Army Chief of Staff,Department of the Army,Vacant,Chief of Staff,Army,Pentagon,Highest ranking Army officer
6,Army Vice Chief of Staff,Department of the Army,LTG Christopher C. LaNeve,Vice Chief of Staff,Army,Pentagon,Second highest ranking Army officer
6,Office of the Secretary of the Army,Department of the Army,Daniel P. Driscoll,Secretary,Army,Pentagon,Civilian leadership of Army
6,ASA Financial Management and Comptroller,Office of the Secretary of the Army,Marc E. Andersen,Assistant Secretary,Army,Pentagon,Manages Army budget
6,ASA Installations Energy and Environment,Office of the Secretary of the Army,William Jordan Gillis,Assistant Secretary,Army,Pentagon,Manages Army installations and environment
6,ASA Civil Works,Office of the Secretary of the Army,Adam Telle,Assistant Secretary,Army,Pentagon,Manages Army civil works projects
6,ASA Manpower and Reserve Affairs,Office of the Secretary of the Army,Derrick M. Anderson,Senior Official Performing Duties,Army,Pentagon,Manages Army personnel
6,ASA Acquisition Logistics and Technology ASA ALT,Office of the Secretary of the Army,Brent Ingraham,Assistant Secretary,Army,Pentagon,Top Army acquisition executive
6,Army General Counsel,Office of the Secretary of the Army,Charles Young III,General Counsel,Army,Pentagon,Chief legal officer of Army
6,Army Staff G-1 Personnel,Department of the Army,LTG Brian S. Eifler,Deputy Chief of Staff,Army,Pentagon,Army personnel directorate
6,Army Staff G-2 Intelligence,Department of the Army,LTG Michelle A. Schmidt,Deputy Chief of Staff,Army,Pentagon,Army intelligence directorate
6,Army Staff G-3/5/7 Operations,Department of the Army,MG Stephanie R. Ahern,Deputy Chief of Staff,Army,Pentagon,Operations plans and training
6,Army Staff G-4 Logistics,Department of the Army,LTG Michelle K. Donahue,Deputy Chief of Staff,Army,Pentagon,Army logistics directorate
6,Army Staff G-6 Network,Department of the Army,LTG Jeth B. Rey,Deputy Chief of Staff,Army,Pentagon,Army network and communications
6,Army Staff G-8 Programs,Department of the Army,LTG Peter N. Bechoff,Deputy Chief of Staff,Army,Pentagon,Army programs and budget
6,Army INSCOM,Department of the Army,MG Timothy D. Brown,Commanding General,Army,Fort Belvoir VA,Army Intelligence and Security Command
6,U.S. Army Pacific USARPAC,Department of the Army,GEN Ronald Clark,Commander,Army,Fort Shafter HI,Army component command for Indo-Pacific
6,U.S. Army Europe and Africa,Department of the Army,GEN Christopher Donahue,Commanding General,Army,Wiesbaden Germany,Army component for Europe and Africa
6,U.S. Army Western Hemisphere Command,Department of the Army,GEN Joseph Ryan,Commander,Army,San Antonio TX,Merged FORSCOM Army North and Army South
6,Army Cyber Command ARCYBER,Department of the Army,LTG Christopher Eubank,Commanding General,Army,Fort Eisenhower GA,Army cyber operations
6,Army Special Operations Command,Department of the Army,LTG Lawrence Gil Ferguson,Commanding General,Army,Fort Bragg NC,Army special operations
6,Army National Guard,Department of the Army,LTG Jonathan M. Stubbs,Director,Army,Arlington VA,National Guard Bureau Army
6,Army Materiel Command AMC,Department of the Army,LTG Chris Mohan,Commanding General,Army,Redstone Arsenal AL,Army logistics and materiel
6,Army Transformation and Training Command T2COM,Department of the Army,LTG Edmond Miles Brown,Acting Commanding General,Army,Fort Eustis VA,Merged TRADOC and Army Futures Command
6,Army Contracting Command ACC,Army Materiel Command,MG Douglas S. Lowrey,Commanding General,Army,Redstone Arsenal AL,Army contracting
6,Army Aviation and Missile Command AMCOM,Army Materiel Command,MG Lori L. Robinson,Commanding General,Army,Redstone Arsenal AL,Aviation and missile logistics
6,Army Communications-Electronics Command CECOM,Army Materiel Command,MG James D. Turinetti IV,Commanding General,Army,Aberdeen Proving Ground MD,Communications and electronics
6,Army Test and Evaluation Command ATEC,Army Materiel Command,MG Patrick L. Gaydon,Commanding General,Army,Aberdeen Proving Ground MD,Army testing and evaluation
6,Army Sustainment Command ASC,Army Materiel Command,MG Eric P. Shirley,Commanding General,Army,Rock Island Arsenal IL,Army sustainment
6,Tank-Automotive and Armaments Command TACOM,Army Materiel Command,BG Beth A. Behn,Commanding General,Army,Warren MI,Tank and automotive systems
6,Army Security Assistance Command USASAC,Army Materiel Command,BG Allen J. Pepper,Commanding General,Army,Warren MI,Foreign military sales
6,Joint Munitions Command JMC,Army Materiel Command,BG Daniel J. Duncan,Commander,Army,Rock Island Arsenal IL,Joint munitions management
6,DEVCOM Combat Capabilities Development Command,Army Transformation and Training Command,BG Robert G. Born,Commanding General,Army,Aberdeen Proving Ground MD,Army research and development
6,Army Research Laboratory ARL,DEVCOM,Dr. Eric L. Moore,Acting Director,Army,Aberdeen Proving Ground MD,Army basic and applied research
6,DEVCOM C5ISR Center,DEVCOM,Elizabeth Beth Ferry SES,Director,Army,Aberdeen Proving Ground MD,Command control communications intelligence
6,DEVCOM Armaments Center,DEVCOM,Chris J. Grassano,Director,Army,Picatinny Arsenal NJ,Armaments research
6,DEVCOM Aviation and Missile Center,DEVCOM,Dr. James Kirsch SES,Director,Army,Redstone Arsenal AL,Aviation and missile research
6,DEVCOM Chemical Biological Center,DEVCOM,Mr. Michael Bailey,Director,Army,Aberdeen Proving Ground MD,Chemical biological defense
6,DEVCOM Ground Vehicle Systems Center GVSC,DEVCOM,Mr. Michael Cadieux,Director,Army,Warren MI,Ground vehicle systems
6,DEVCOM Soldier Center,DEVCOM,Mr. Douglas A. Tamilio,Director,Army,Natick MA,Soldier performance and protection
6,DEVCOM Analysis Center,DEVCOM,Mr. Larry Larimer,Director,Army,Aberdeen Proving Ground MD,Army analysis
6,Engineer Research and Development Center ERDC,Army Corps of Engineers,Dr. Beth Fleming SES,Director,Army,Vicksburg MS,Engineer research
6,Army Medical Research and Development Command,Army Transformation and Training Command,MG Paula C. Lodi,Commanding General,Army,Fort Detrick MD,Medical research
6,Army Software Factory,Army Transformation and Training Command,COL Vito Errico,Director,Army,Austin TX,Software development for soldiers
6,Army Application Lab AAL,Army Pathway for Innovation and Technology,Dr. Casey Perley,Executive Director,Army,Austin TX,Army applications lab
6,Army FUZE Program,Army Pathway for Innovation and Technology,Matt Willis,Director,Army,Multiple,Combines SBIR TMI ManTech and xTech
6,Army xTech Program,Army FUZE,Ms. Jessica Stillman,Program Manager,Army,Multiple,Army innovation prize competitions
6,Army University,Army Combined Arms Command,LTG James P. Isenhower III,Commanding General,Army,Fort Leavenworth KS,Army education
6,Army War College,Army University,MG Trevor J. Bredenkamp,Commandant,Army,Fort Leavenworth KS,Senior professional military education
6,U.S. Army Special Forces Command,Army Special Operations Command,BG Joseph Wortham,Commander,Army,Fort Bragg NC,Special forces
6,101st Airborne Division,XVIII Airborne Corps,MG David W. Gardner,Commanding General,Army,Fort Campbell KY,Air assault division
6,82nd Airborne Division,XVIII Airborne Corps,MG Brandon Tegtmeier,Commanding General,Army,Fort Liberty NC,Parachute infantry division
6,3rd Infantry Division,U.S. Army Western Hemisphere Command,MG John W. Lubas,Commander,Army,Fort Stewart GA,Heavy mechanized division
6,10th Mountain Division,U.S. Army Western Hemisphere Command,MG Scott M. Naumann,Commander,Army,Fort Drum NY,Light infantry mountain division
6,25th Infantry Division,U.S. Army Pacific,MG James Bartholomees,Commanding General,Army,Schofield Barracks HI,Tropical light infantry
6,1st Cavalry Division,U.S. Army Europe and Africa,MG Thomas Feltey,Commander,Army,Fort Cavazos TX,Heavy armored division
6,4th Infantry Division,U.S. Army Pacific,MG Patrick Ellis,Commanding General,Army,Fort Carson CO,Mountain mechanized division
6,7th Infantry Division,U.S. Army Pacific,MG Bernard J. Harrington,Commanding General,Army,Lewis-McChord WA,Multi-domain task force
6,1st Multi-Domain Task Force,U.S. Army Pacific,COL Charles Kean,Commander,Army,Lewis-McChord WA,Multi-domain operations
6,III Armored Corps,U.S. Army Europe and Africa,LTG Kevin D. Admiral,Commanding General,Army,Fort Cavazos TX,Heavy corps
6,I Corps,U.S. Army Pacific,LTG Matthew W. McFarlane,Commanding General,Army,Lewis-McChord WA,I Corps
6,V Corps,U.S. Army Europe and Africa,LTG Charles D. Costanza,Commanding General,Army,Fort Knox KY,V Corps
6,XVIII Airborne Corps,U.S. Army Western Hemisphere Command,LTG Gregory K. Anderson,Commanding General,Army,Fort Liberty NC,Airborne corps
6,PAE Maneuver Ground,ASA ALT,MG Colin P. Tuley,Portfolio Acquisition Executive,Army,Fort Benning GA,Tanks IFVs and soldier systems
6,PAE Maneuver Air,ASA ALT,MG Clair A. Gill,Portfolio Acquisition Executive,Army,Fort Rucker AL,Helicopters UAS and autonomy
6,PAE Fires,ASA ALT,MG Frank J. Lozano,Portfolio Acquisition Executive,Army,Redstone Arsenal AL,Missiles artillery and long-range precision
6,PAE C2/CC2,ASA ALT,Mr. Joseph D. Welch SES,Portfolio Acquisition Executive,Army,Aberdeen Proving Ground MD,Networks EW sensors and battle management
6,PAE Agile Sustainment and Ammunition,ASA ALT,MG John B. Reim,Portfolio Acquisition Executive,Army,Picatinny Arsenal NJ,Logistics and ammunition production
6,PAE Layered Protection and CBRN,ASA ALT,MG Christopher Beck,Portfolio Acquisition Executive,Army,Fort Leonard Wood MO,Air defense CBRN and counter-drone
6,CPE Enterprise Software and Service ES2,ASA ALT,Ms. Miranda Coleman,Acting CPE,Army,Multiple,Enterprise business systems
6,Army Pathway for Innovation and Technology PIT,ASA ALT,COL Shermoan Daiyaan,Director,Army,Multiple,Front door for startups
5,Office of the Secretary of the Air Force,Department of the Air Force,Dr. Troy E. Meink,Secretary,Air Force/Space Force,Pentagon,Civilian leadership
5,Under Secretary of the Air Force,Office of the Secretary of the Air Force,Matthew Lohmeier,Under Secretary,Air Force/Space Force,Pentagon,Second highest civilian
5,SAF Manpower and Reserve Affairs,Office of the Secretary of the Air Force,Richard Anderson,Assistant Secretary,Air Force/Space Force,Pentagon,Air Force personnel
5,SAF Financial Management and Comptroller,Office of the Secretary of the Air Force,Philip Dave Weinberg,Assistant Secretary,Air Force/Space Force,Pentagon,Air Force budget
5,SAF Acquisition Technology and Logistics SAF AQ,Office of the Secretary of the Air Force,William D. Bailey SES,Performing Duties,Air Force/Space Force,Pentagon,Top Air Force acquisition executive
5,SAF Installations Environment and Energy,Office of the Secretary of the Air Force,Michael E. Saunders SES,Acting Assistant Secretary,Air Force/Space Force,Pentagon,Air Force installations
5,SAF Space Acquisition and Integration,Office of the Secretary of the Air Force,Erich Hernandez-Baquero,Assistant Secretary,Air Force/Space Force,Pentagon,Space acquisition
5,Air Force General Counsel,Office of the Secretary of the Air Force,William Lane III,General Counsel,Air Force/Space Force,Pentagon,Air Force legal
5,Air Force Chief of Staff,Department of the Air Force,GEN Kenneth S. Wilsbach,Chief of Staff,Air Force/Space Force,Pentagon,Highest ranking Air Force officer
5,Vice Chief of Staff of the Air Force,Department of the Air Force,GEN John D. Lamontagne,Vice Chief of Staff,Air Force/Space Force,Pentagon,Second highest Air Force
5,Air Force A1 Manpower Personnel Services,Air Force Chief of Staff,LTG Jefferson J. ODonnell,Deputy Chief of Staff,Air Force/Space Force,Pentagon,Air Force personnel
5,Air Force A2 Intelligence,Air Force Chief of Staff,LTG Max E. Pearson,Deputy Chief of Staff,Air Force/Space Force,Pentagon,Air Force intelligence
5,Air Force A3 Operations,Air Force Chief of Staff,LTG Case A. Cunningham,Deputy Chief of Staff,Air Force/Space Force,Pentagon,Air Force operations
5,Air Force A4 Logistics Engineering,Air Force Chief of Staff,LTG Kenyon K. Bell,Deputy Chief of Staff,Air Force/Space Force,Pentagon,Air Force logistics
5,Air Force A5/7 Strategy Integration,Air Force Chief of Staff,LTG Christopher J. Niemi,Deputy Chief of Staff,Air Force/Space Force,Pentagon,Air Force strategy
5,Air Force A6 Warfighter Communications,Air Force Chief of Staff,MG Michele C. Edmondson,Deputy Chief of Staff,Air Force/Space Force,Pentagon,Air Force cyber
5,Air Force A8 Plans and Programs,Air Force Chief of Staff,LTG David H. Tabor,Deputy Chief of Staff,Air Force/Space Force,Pentagon,Air Force plans
5,Air Force A10 Strategic Deterrence,Air Force Chief of Staff,LTG Brandon D. Parker,Deputy Chief of Staff,Air Force/Space Force,Pentagon,Nuclear deterrence
5,Air Force Materiel Command AFMC,Air Force Chief of Staff,LTG Linda S. Hurry,Commander,Air Force/Space Force,Dayton OH,Air Force materiel
5,Air Combat Command ACC,Air Force Chief of Staff,GEN Adrian L. Spain,Commander,Air Force/Space Force,Langley AFB VA,Air combat
5,Air Education and Training Command AETC,Air Force Chief of Staff,LTG Clark J. Quinn,Commander,Air Force/Space Force,San Antonio TX,Air Force training
5,Air Force Global Strike Command AFGSC,Air Force Chief of Staff,GEN Stephen L. Davis,Commander,Air Force/Space Force,Barksdale AFB LA,Strategic nuclear deterrence
5,Air Mobility Command AMC,U.S. Transportation Command,LTG Daniel H. Tulley,Commander,Air Force/Space Force,Scott AFB IL,Air mobility
5,Pacific Air Forces PACAF,Air Force Chief of Staff,GEN Kevin B. Schneider,Commander,Air Force/Space Force,Hickam AFB HI,Pacific air
5,Air Force Special Operations Command AFSOC,Air Force Chief of Staff,LTG Michael E. Conley,Commander,Air Force/Space Force,Hurlburt Field FL,Air Force special operations
5,Air Force Life Cycle Management Center AFLCMC,Air Force Materiel Command,LTG Donna D. Shipton,Commander,Air Force/Space Force,Dayton OH,Life cycle management
5,Air Force Sustainment Center,Air Force Materiel Command,LTG Jennifer Hammerstedt,Commander,Air Force/Space Force,Tinker AFB OK,Sustainment and depot
5,Air Force Research Laboratory AFRL,Air Force Materiel Command,BG Jason E. Bartolomei,Commander,Air Force/Space Force,Dayton OH,Research and development
5,Air Force Nuclear Weapons Center AFNWC,Air Force Materiel Command,BG William Rogers,Commander,Air Force/Space Force,Kirtland AFB NM,Nuclear weapons
5,Air Force Test Center,Air Force Materiel Command,Various,Commander,Air Force/Space Force,Edwards AFB CA,Test and evaluation
5,Air Force Academy,Air Force Chief of Staff,LTG Paul D. Moga,Superintendent,Air Force/Space Force,Colorado Springs CO,Service academy
5,Air University,Air Education and Training Command,LTG Daniel H. Tulley,Commander,Air Force/Space Force,Maxwell AFB AL,Air Force education
5,Second Air Force,Air Education and Training Command,MG Wolfe Davidson,Commander,Air Force/Space Force,San Antonio TX,Basic training
5,Air Force Warfare Center,Air Combat Command,BG David C. Epperson,Commander,Air Force/Space Force,Nellis AFB NV,Warfare center
5,1st Air Force Air Forces Northern,Air Combat Command,LTG M. Luke Ahmann,Commander,Air Force/Space Force,Tyndall AFB FL,Air defense NORTHCOM
5,9th Air Force Air Forces Central,Air Combat Command,LTG Derek C. France,Commander,Air Force/Space Force,Shaw AFB SC,Air defense CENTCOM
5,12th Air Force Air Forces Southern,Air Combat Command,MG David A. Mineau,Commander,Air Force/Space Force,Davis-Monthan AFB AZ,Air defense SOUTHCOM
5,16th Air Force Air Forces Cyber,Air Combat Command,LTG Thomas K. Hensley,Commander,Air Force/Space Force,Lackland AFB TX,Cyber operations
5,3rd Air Force,U.S. Air Forces in Europe,MG Paul D. Moga,Commander,Air Force/Space Force,Ramstein AB Germany,Europe air
5,5th Air Force,Pacific Air Forces,LTG Joel L. Carey,Commander,Air Force/Space Force,Yokota AB Japan,Japan air
5,7th Air Force,Pacific Air Forces,LTG David R. Iverson,Commander,Air Force/Space Force,Osan AB Korea,Korea air
5,11th Air Force,Pacific Air Forces,LTG David R. Iverson,Commander,Air Force/Space Force,JBER Alaska,Alaska air
5,8th Air Force,Air Force Global Strike Command,MG Ty W. Neuman,Commander,Air Force/Space Force,Barksdale AFB LA,Bomber force
5,20th Air Force,Air Force Global Strike Command,MG Stacey J. Huser,Commander,Air Force/Space Force,F.E. Warren AFB WY,ICBM force
5,AFWERX,Air Force Research Laboratory,COL Nathan C. Stuckey,Director,Air Force/Space Force,Dayton OH,Air Force innovation arm
5,SpaceWERX,Air Force Research Laboratory,Arthur F. Grijalva,Director,Air Force/Space Force,Kirtland AFB NM,Space Force innovation arm
5,Air Force Office of Scientific Research AFOSR,Air Force Research Laboratory,Dr. Lovica Ware,Acting Director,Air Force/Space Force,Arlington VA,Basic research
5,PAE C3BM,SAF AQ,MG Luke Cropsey,Portfolio Acquisition Executive,Air Force/Space Force,Lexington MA,Command control communications battle management
5,PAE Fighters and Advanced Aircraft,SAF AQ,COL Timothy Helfrich,Portfolio Acquisition Executive,Air Force/Space Force,Dayton OH,Fighters and advanced aircraft
5,PAE Nuclear Command Control and Communications NC3,SAF AQ,Scott Hardiman SES,Portfolio Acquisition Executive,Air Force/Space Force,Dayton OH,NC3 systems
5,PAE Propulsion,SAF AQ,John Sneden SES,Portfolio Acquisition Executive,Air Force/Space Force,Dayton OH,Propulsion systems
5,PAE Weapons,SAF AQ,BG Robert Lyons III,Portfolio Acquisition Executive,Air Force/Space Force,Eglin AFB FL,Weapons systems
5,PEO Combat and Mission Support Services,SAF AQ,Randall D. Culpepper,Program Executive Officer,Air Force/Space Force,San Antonio TX,Combat support
5,Air Force Rapid Capabilities Office AFRCO,SAF AQ,William D. Bailey SES,Program Executive Officer,Air Force/Space Force,Dayton OH,Rapid capabilities
5,AFLCMC PEO C3BM,Air Force Life Cycle Management Center,BG Jason D. Voorheis,Program Executive Officer,Air Force/Space Force,Lexington MA,C3BM
5,AFLCMC PEO Armament,Air Force Life Cycle Management Center,BG Robert Lyons III,Program Executive Officer,Air Force/Space Force,Eglin AFB FL,Armaments
5,AFLCMC PEO Business and Enterprise Systems,Air Force Life Cycle Management Center,Mr. Alvin Burse SES,Program Executive Officer,Air Force/Space Force,Maxwell AFB AL,Business systems
5,AFLCMC PEO Electronic Systems,Air Force Life Cycle Management Center,Ms. Lea Kirkwood SES,Program Executive Officer,Air Force/Space Force,Lexington MA,Electronic systems
5,AFLCMC PEO Cyber and Networks,Air Force Life Cycle Management Center,BG Joshua P. Williams,Program Executive Officer,Air Force/Space Force,Lexington MA,Cyber and networks
5,AFLCMC PEO Fighters and Advanced Aircraft,Air Force Life Cycle Management Center,COL Timothy Helfrich,Program Executive Officer,Air Force/Space Force,Dayton OH,Fighters
5,AFLCMC PEO Bombers,Air Force Life Cycle Management Center,COL Timothy Spaulding,Program Executive Officer,Air Force/Space Force,Dayton OH,Bombers
5,AFLCMC PEO ISR and SOF,Air Force Life Cycle Management Center,COL John Dayton,Program Executive Officer,Air Force/Space Force,Dayton OH,ISR and SOF
5,AFLCMC PEO Mobility,Air Force Life Cycle Management Center,Kevin Stamey SES,Program Executive Officer,Air Force/Space Force,Dayton OH,Mobility aircraft
5,AFLCMC PEO Training,Air Force Life Cycle Management Center,Rodney Stevens SES,Program Executive Officer,Air Force/Space Force,Dayton OH,Training aircraft
5,AFLCMC PEO Presidential and Executive Aircraft,Air Force Life Cycle Management Center,BG William L. Ottati,Program Executive Officer,Air Force/Space Force,Dayton OH,VC-25 and executive aircraft
5,AFLCMC PEO Joint Strike Fighter,Air Force Life Cycle Management Center,LTG Gregory L. Masiello,Program Executive Officer,Air Force/Space Force,Arlington VA,F-35 program
4,United States Space Force,Department of the Air Force,GEN B. Chance Saltzman,Chief of Space Operations,Space Force,Pentagon,Independent military service for space
5,Chief of Space Operations,United States Space Force,GEN B. Chance Saltzman,Chief of Space Operations,Space Force,Pentagon,Highest ranking Space Force officer
5,Vice Chief of Space Operations,United States Space Force,GEN Shawn N. Bratton,Vice CSO,Space Force,Pentagon,Second highest Space Force officer
5,Space Force HQ Staff S-1 Personnel,Chief of Space Operations,Katharine Kelley SES,Deputy Chief,Space Force,Pentagon,Space Force personnel
5,Space Force HQ Staff S-2 Intelligence,Chief of Space Operations,BG Brian D. Sidari,Deputy Chief,Space Force,Pentagon,Space Force intelligence
5,Space Force HQ Staff S-3/4/7/10 Operations,Chief of Space Operations,LTG Douglas Schiess,Deputy Chief,Space Force,Pentagon,Space Force operations
5,Space Force HQ Staff S-5/8 Strategy,Chief of Space Operations,LTG David N. Miller,Deputy Chief CSRO,Space Force,Pentagon,Space Force strategy
5,Space Force HQ Staff S-6 Cyber Data,Chief of Space Operations,Ms. Charleen Laughlin SES,Deputy Chief,Space Force,Pentagon,Space Force cyber
5,Space Systems Command SSC,Chief of Space Operations,LTG Philip A. Garrant,Commander,Space Force,Los Angeles AFB CA,Space acquisition
5,Combat Forces Command SpOC,Chief of Space Operations,LTG Greg Gagnon,Commander,Space Force,Peterson SFB CO,Space operations
5,Space Training and Readiness Command STARCOM,Chief of Space Operations,MG James E. Smith,Commander,Space Force,Peterson SFB CO,Space training
5,Space Development Agency SDA,Space Systems Command,Dr. Gurpartap GP Sandhoo,Director,Space Force,Chantilly VA,Space development
5,Space Rapid Capabilities Office SpRCO,Space Systems Command,Dr. Kelly D. Hammett SES,Program Executive Officer,Space Force,Albuquerque NM,Space rapid capabilities
5,Space Delta 2 Space Domain Awareness,Combat Forces Command,COL Barry A. Croker,Commander,Space Force,Peterson SFB CO,Space domain awareness
5,Space Delta 3 Space Electromagnetic Warfare,Combat Forces Command,COL Angelo Fernandez,Commander,Space Force,Peterson SFB CO,Space EW
5,Space Delta 4 Missile Warning,Combat Forces Command,COL Aaron L. Cochran,Commander,Space Force,Buckley SFB CO,Missile warning
5,Space Delta 6 Cyberspace Warfare,Combat Forces Command,COL Travis R. Prater,Commander,Space Force,Schriever SFB CO,Cyberspace
5,Space Delta 7 ISR and Targeting,Combat Forces Command,COL Phoenix L. Hauser,Commander,Space Force,Peterson SFB CO,Space ISR
5,Space Delta 8 SATCOM Early Warning,Combat Forces Command,COL Jeffery E. Weisler,Commander,Space Force,Schriever SFB CO,SATCOM
5,Space Delta 9 Orbital Warfare,Combat Forces Command,COL Ramsey M. Horn,Commander,Space Force,Schriever SFB CO,Orbital warfare
5,Space Delta 1 Training,Space Training and Readiness Command,COL Krista N. St Romain,Commander,Space Force,Peterson SFB CO,Space training
5,Space Delta 10 Wargaming,Space Training and Readiness Command,COL Shannon DaSilva,Commander,Space Force,Peterson SFB CO,Space wargaming
5,Space Delta 11 Range Aggressors,Space Training and Readiness Command,COL Agustin Carrero,Commander,Space Force,Peterson SFB CO,Space aggressors
5,Space Delta 12 Test Evaluation,Space Training and Readiness Command,COL Sacha Tomlinson,Commander,Space Force,Peterson SFB CO,Space test
5,Space Delta 13 Education,Space Training and Readiness Command,COL Alison R. Gonzalez,Commander,Space Force,Peterson SFB CO,Space education
5,Space Launch Delta 30,Space Systems Command,COL James Horne,Commander,Space Force,Vandenberg SFB CA,Western launch
5,Space Launch Delta 45,Space Systems Command,COL Brian L. Chatman,Director Eastern Range,Space Force,Patrick SFB FL,Eastern launch
5,Space Base Delta 2,Space Systems Command,COL Eamon R. Murray,Commander,Space Force,Peterson SFB CO,Base support
5,PAE Space-Based Sensing and Targeting,Space Systems Command,COL Ryan Frazier,Acting PAE,Space Force,Los Angeles AFB CA,Space-based sensing
5,PAE Assured Access to Space,Space Systems Command,COL Eric Zarybnisky,Portfolio Acquisition Executive,Space Force,Los Angeles AFB CA,Space access
5,PAE Space Combat Power,Space Systems Command,COL Bryon E. C. McClain,Program Executive Officer,Space Force,Los Angeles AFB CA,Space combat power
5,PAE Battle Management C3,Space Systems Command,Shannon Pallone,Portfolio Acquisition Executive,Space Force,Los Angeles AFB CA,Battle management
5,PAE Military Comms and PNT,Space Systems Command,Erin Carper,Program Executive Officer,Space Force,Los Angeles AFB CA,Military comms and PNT
5,PAE Operational Test and Training Infrastructure,Space Systems Command,COL Corey Klopstein,Program Executive Officer,Space Force,Los Angeles AFB CA,OTTI
5,Space Systems Integration Office SSIO,Space Systems Command,COL Jon Strizzi,Director,Space Force,Los Angeles AFB CA,Space systems integration
5,Commercial Space Office COMSO,Space Systems Command,COL Tim Trimailo,Director,Space Force,Los Angeles AFB CA,Commercial space
5,System Delta 84,Space Systems Command,COL Stevie Medeiros,Commander,Space Force,Los Angeles AFB CA,Space sensing
5,System Delta 85,Space Systems Command,COL Jason West,Commander,Space Force,Los Angeles AFB CA,Space domain awareness
5,System Delta 810,Space Systems Command,COL Dane Bannach,Commander,Space Force,Los Angeles AFB CA,Space-based sensing
5,System Delta 80,Space Systems Command,CAPT Ginny Weinert,Commander,Space Force,Los Angeles AFB CA,Assured access
5,System Delta 81,Space Systems Command,COL Corey Klopstein,Commander,Space Force,Los Angeles AFB CA,OTTI
5,System Delta 831,Space Systems Command,COL Neil Barnas,Commander,Space Force,Los Angeles AFB CA,PNT
5,System Delta 88,Space Systems Command,COL A.J. Hammer Ashby,Commander,Space Force,Los Angeles AFB CA,SATCOM
5,System Delta 89,Space Systems Command,COL Brendan Hochstein,Commander,Space Force,Los Angeles AFB CA,Combat power
4,United States Coast Guard,Department of Homeland Security,ADM Kevin Lunday,Commandant,Coast Guard,Washington DC,Part of DHS not DoW
5,Coast Guard Deputy Commandant for Mission Support,Coast Guard Headquarters,RADM Charles Fosse,Deputy Commandant,Coast Guard,Washington DC,CG mission support
5,Coast Guard Deputy Commandant for Operations,Coast Guard Headquarters,RADM Douglas M. Schofield,Acting Deputy Commandant,Coast Guard,Washington DC,CG operations
5,Coast Guard Deputy Commandant for Systems,Coast Guard Headquarters,RADM Chad Jacoby,Deputy Commandant,Coast Guard,Washington DC,CG systems
5,Coast Guard Force Readiness Command FORCECOM,Coast Guard Headquarters,RADM Jeffrey K. Randall,Commander,Coast Guard,Norfolk VA,CG readiness
5,Coast Guard Operational Logistics Command LOGCOM,Coast Guard Headquarters,RADM Carola List,Commander,Coast Guard,Norfolk VA,CG logistics
5,Coast Guard Atlantic Area,Coast Guard Headquarters,VADM Nathan A. Moore,Commander,Coast Guard,Portsmouth VA,CG Atlantic
5,Coast Guard Pacific Area,Coast Guard Headquarters,VADM Joseph R. Buzzella,Commander,Coast Guard,Alameda CA,CG Pacific
5,Coast Guard Special Missions Command,Coast Guard Headquarters,Various,Commander,Coast Guard,Multiple,CG special missions
5,Coast Guard Research and Development Center RDC,Coast Guard Headquarters,CAPT Michael Chien,Commanding Officer,Coast Guard,New London CT,CG R&D
5,Coast Guard Aviation Logistics Center ALC,Coast Guard Headquarters,CAPT Christian Polyak,Commanding Officer,Coast Guard,Elizabeth City NC,CG aviation logistics
5,Coast Guard Surface Forces Logistics Center SFLC,Coast Guard Headquarters,CAPT Andrew Pecora,Commanding Officer,Coast Guard,Baltimore MD,CG surface logistics
5,Coast Guard C5I Service Center C5ISC,Coast Guard Headquarters,CAPT Benjamin Goff,Commanding Officer,Coast Guard,Alexandria VA,CG C5I
5,Coast Guard Shore Infrastructure Logistics Center SILC,Coast Guard Headquarters,CAPT John Berry,Commanding Officer,Coast Guard,Norfolk VA,CG shore
5,PEO Robotics and Autonomous Systems,Coast Guard Systems,Mr. Anthony J.L. Antognoli,Program Executive Officer,Coast Guard,Washington DC,CG RAS
5,CG-RAPTOR Team,Coast Guard Systems,CAPT Chad Brick,Chief,Coast Guard,Washington DC,CG rapid prototyping
4,U.S. Central Command CENTCOM,Combatant Commands,ADM Brad Cooper,Commander,DoW,MacDill AFB FL,Central Command Middle East
4,U.S. Africa Command AFRICOM,Combatant Commands,GEN Dagvin R.M. Anderson,Commander,DoW,Stuttgart Germany,Africa Command
4,U.S. European Command EUCOM,Combatant Commands,GEN Alexus G. Grynkewich,Commander,DoW,Stuttgart Germany,European Command
4,U.S. Indo-Pacific Command INDOPACOM,Combatant Commands,ADM Samuel Paparo,Commander,DoW,Camp H.M. Smith HI,Indo-Pacific Command
4,U.S. Northern Command NORTHCOM,Combatant Commands,GEN Gregory M. Guillot,Commander,DoW,Peterson AFB CO,Northern Command
4,U.S. Southern Command SOUTHCOM,Combatant Commands,LTG Frank Donovan,Commander,DoW,Miami FL,Southern Command
4,U.S. Space Command SPACECOM,Combatant Commands,GEN Stephen N. Whiting,Commander,DoW,Schriever SFB CO,Space Command
4,U.S. Special Operations Command SOCOM,Combatant Commands,ADM Frank Mitch M. Bradley,Commander,DoW,MacDill AFB FL,Special Operations Command
4,U.S. Transportation Command TRANSCOM,Combatant Commands,GEN Randall Reed,Commander,DoW,Scott AFB IL,Transportation Command
4,U.S. Strategic Command STRATCOM,Combatant Commands,ADM Richard Correll,Commander,DoW,Offutt AFB NE,Strategic Command
4,U.S. Cyber Command CYBERCOM,Combatant Commands,LTG Joshua M. Rudd,Commander,DoW,Fort Meade MD,Cyber Command
5,U.S. Army Central ARCENT,U.S. Central Command,Various,Commander,Army,Shaw AFB SC,Army Central
5,Naval Forces Central Command NAVCENT,U.S. Central Command,VADM Curt A. Renshaw,Commander,DoN,Manama Bahrain,5th Fleet
5,Air Forces Central Command AFCENT,U.S. Central Command,LTG Derek C. France,Commander,Air Force,Shaw AFB SC,9th Air Force
5,Marine Forces Central MARCENT,U.S. Central Command,LTG Joseph Clearfield,Commander,DoN,MacDill AFB FL,Marine Central
5,Special Operations Command Central SOCCENT,U.S. Central Command,MG Jasper Jeffers,Commander,DoW,MacDill AFB FL,SOF Central
5,U.S. Space Forces Central SPACECENT,U.S. Central Command,COL Chris Putman,Commander,Space Force,MacDill AFB FL,Space Central
5,U.S. Air Forces Africa USAFE-AFAFRICA,U.S. Africa Command,LTG Jason T. Hinds,Commander,Air Force,Stuttgart Germany,Air Force Africa
5,U.S. Naval Forces Africa NAVAF,U.S. Africa Command,ADM George M. Wikoff,Commander,DoN,Stuttgart Germany,Naval Africa
5,Special Operations Command Africa,U.S. Africa Command,MG Claude K. Tudor Jr.,Commander,DoW,Stuttgart Germany,SOF Africa
5,U.S. Air Forces in Europe USAFE,U.S. European Command,LTG Jason T. Hinds,Commander,Air Force,Stuttgart Germany,Air Force Europe
5,U.S. Naval Forces Europe-Africa NAVEUR-NAVAF,U.S. European Command,ADM George M. Wikoff,Commander,DoN,Stuttgart Germany,Naval Europe-Africa
5,Special Operations Command Europe SOCEUR,U.S. European Command,LTG Richard E. Angle,Deputy Commander,DoW,Stuttgart Germany,SOF Europe
5,U.S. Pacific Fleet PACFLT,U.S. Indo-Pacific Command,ADM Stephen Web Koehler,Commander,DoN,Pearl Harbor HI,Pacific Fleet
5,U.S. Pacific Air Forces PACAF,U.S. Indo-Pacific Command,GEN Kevin B. Schneider,Commander,Air Force,Hickam AFB HI,Pacific Air
5,U.S. Forces Japan USFJ,U.S. Indo-Pacific Command,LTG Stephen F. Jost,Commander,DoW,Yokota AB Japan,US Forces Japan
5,U.S. Forces Korea USFK,U.S. Indo-Pacific Command,GEN Xavier T. Brunson,Commander,DoW,Yongsan Korea,US Forces Korea
5,Special Operations Command Pacific SOCPAC,U.S. Indo-Pacific Command,MG Jeffrey A. VanAntwerp,Commander,DoW,Camp H.M. Smith HI,SOF Pacific
5,U.S. Space Forces Indo-Pacific,U.S. Indo-Pacific Command,BG Brian A. Denaro,Commander,Space Force,Joint Base Pearl Harbor HI,Space INDOPACOM
5,Joint Interagency Task Force West JIATF West,U.S. Indo-Pacific Command,CAPT George Howell,Director,DoW,Camp H.M. Smith HI,Counterdrug task force
5,U.S. Naval Forces Southern Command,U.S. Southern Command,RADM Carlos Sardiello,Commander,DoN,Mayport FL,4th Fleet
5,Air Forces Southern AFSOUTH,U.S. Southern Command,MG David A. Mineau,Commander,Air Force,Davis-Monthan AFB AZ,12th Air Force
5,Special Operations Command South SOCSOUTH,U.S. Southern Command,RADM Mark A. Schafer,Commander,DoW,Miami FL,SOF South
5,U.S. Space Forces Space S4S,U.S. Space Command,LTG Dennis Bythewood,Commander,Space Force,Schriever SFB CO,Space Forces Space
5,Joint Special Operations Command JSOC,U.S. Special Operations Command,LTG Jonathan P. Braga,Commander,DoW,Fort Bragg NC,JSOC
5,Naval Special Warfare Command SEALs,U.S. Special Operations Command,RADM Walter H. Allman III,Commander,DoN,Coronado CA,Naval special warfare
5,1st Special Forces Command,U.S. Special Operations Command,BG Joseph Wortham,Commander,Army,Fort Bragg NC,Special forces
5,Air Force Special Operations Command AFSOC,U.S. Special Operations Command,LTG Michael E. Conley,Commander,Air Force,Hurlburt Field FL,AFSOC
5,Marine Special Operations Command MARSOC,U.S. Special Operations Command,MG Peter D. Huntley,Commander,DoN,Camp Lejeune NC,MARSOC
5,PEO Fixed Wing,SOCOM Acquisition,COL T. Justin Bronder,Program Executive Officer,DoW,Patuxent River MD,SOF fixed wing
5,PEO Maritime,SOCOM Acquisition,CAPT Jared Wyrick,Program Executive Officer,DoW,Panama City FL,SOF maritime
5,PEO Rotary Wing,SOCOM Acquisition,Steve Smith,Program Executive Officer,DoW,Patuxent River MD,SOF rotary wing
5,PEO Digital Applications,SOCOM Acquisition,COL Leilani Tydingco-Amarante,Program Executive Officer,DoW,MacDill AFB FL,SOF digital
5,PEO Services,SOCOM Acquisition,Mr. Pete Greany,Program Executive Officer,DoW,MacDill AFB FL,SOF services
5,PEO SOFSA,SOCOM Acquisition,COL Joshua M. Walter,Program Executive Officer,DoW,MacDill AFB FL,SOF support activity
5,PEO Warrior,SOCOM Acquisition,COL Robert Ramsey Oliver,Program Executive Officer,DoW,MacDill AFB FL,SOF warrior
5,PEO Tactical Information Systems,SOCOM Acquisition,Jennifer Powers,Acting Program Executive Officer,DoW,MacDill AFB FL,SOF tactical info systems
5,Joint Special Operations University,SOCOM,Dr. Paul D. Brister,President,DoW,MacDill AFB FL,SOF education
5,SOFWERX,SOCOM,Leslie Babich,Director,DoW,Tampa FL,SOF innovation hub
5,Air Mobility Command AMC,U.S. Transportation Command,LTG Daniel H. Tulley,Commander,Air Force,Scott AFB IL,Air mobility
5,Joint Enabling Capabilities Command,U.S. Transportation Command,MG Michael E. McWilliams,Commander,DoW,Norfolk VA,Joint enabling capabilities
5,Air Force Global Strike Command AFGSC,U.S. Strategic Command,GEN Stephen L. Davis,Commander,Air Force,Barksdale AFB LA,Strategic nuclear
5,DoD Cyber Defense Command DCDC,U.S. Cyber Command,LTG Paul T. Stanton,Commander,DoW,Fort Meade MD,Cyber defense
5,Fleet Cyber Command 10th Fleet,U.S. Cyber Command,VADM Heidi K. Berg,Commander,DoN,Fort Meade MD,Fleet cyber
5,16th Air Force Air Forces Cyber,U.S. Cyber Command,LTG Thomas K. Hensley,Commander,Air Force,Lackland AFB TX,AFCYBER
5,Army Cyber Command ARCYBER,U.S. Cyber Command,LTG Christopher Eubank,Commander,Army,Fort Eisenhower GA,Army cyber
5,Marine Forces Cyberspace Command MARFORCYBER,U.S. Cyber Command,MG Joseph A. Matos III,Commanding General,DoN,Fort Meade MD,Marine cyber
3,Defense Logistics Agency DLA,ASD Sustainment,LTG Mark Simerly,Director,DoD,Fort Belvoir VA,Global logistics
3,Defense Information Systems Agency DISA,USD I&S,LTG Paul T. Stanton,Director,DoD,Fort Meade MD,IT and communications
3,Defense Intelligence Agency DIA,USD I&S,LTG James H. Adams,Director,DoD,Joint Base Anacostia-Bolling,Military intelligence
3,Defense Counterintelligence and Security Agency DCSA,USD I&S,Joseph Tonon,Director,DoD,Boyers PA,Counterintelligence and security
3,Defense Threat Reduction Agency DTRA,ASD ND-CBD,MG Lyle K. Drew,Acting Director,DoD,Fort Belvoir VA,Threat reduction
3,Defense Health Agency DHA,USD P&R,VADM Darin K. Via,Director,DoD,Falls Church VA,Military health
3,Defense Contract Management Agency DCMA,USD A&S,VADM Stephen Tedford,Director,DoD,Fort Lee VA,Contract management
3,Defense Commissary Agency,USD P&R,Mr. John Hall,Director and CEO,DoD,Fort Gregg-Adams VA,Commissary
3,Pentagon Force Protection Agency,OSW,Various,Director,DoD,Pentagon,Pentagon security
3,Defense Media Activity,OSW,Various,Director,DoD,Fort Meade MD,Defense media
3,Defense Finance and Accounting Service DFAS,USD Comptroller,Mr. Jonathan Witter,Director,DoD,Indianapolis IN,Finance and accounting
3,Defense Contract Audit Agency DCAA,USD Comptroller,Ms. Jennifer L. Desautel,Director,DoD,Fort Belvoir VA,Contract audit
3,Defense Technical Information Center DTIC,USD R&E,Dr. Rubino-Hallman,Acting Administrator,DoD,Fort Belvoir VA,Technical information
2,Office of Personnel Management OPM,Executive Branch,Scott Kupor,Director,Federal,Washington DC,Federal HR agency
2,Office of Science and Technology Policy OSTP,White House,Michael Kratsios,Director and U.S. CTO,Federal,Washington DC,White House science office
2,Office of the National Cyber Director NCD,White House,Sean Cairncross,National Cyber Director,Federal,Washington DC,Cyber director
2,Government Accountability Office GAO,Congress,Orice Williams Brown,Acting U.S. Comptroller General,Federal,Washington DC,Government watchdog
2,White House Office of Management and Budget OMB,White House,Russell Vought,Director,Federal,Washington DC,Federal budget office
2,Department of Energy DOE,Executive Branch,Chris Wright,Secretary of Energy,Federal,Washington DC,Energy department
2,Department of Commerce DOC,Executive Branch,Howard Lutnick,Secretary of Commerce,Federal,Washington DC,Commerce department
2,Department of Treasury,Executive Branch,Scott Bessent,Secretary of Treasury,Federal,Washington DC,Treasury department
2,Department of State,Executive Branch,Marco Rubio,Secretary of State,Federal,Washington DC,State department
2,Export-Import Bank EXIM Bank,Executive Branch,John Jovanovic,President and Chairman,Federal,Washington DC,Export credit agency
2,U.S. International Development Finance Corporation DFC,Executive Branch,Ben Black,CEO,Federal,Washington DC,Development finance
2,Nuclear Regulatory Commission NRC,Executive Branch,Various,Chairman,Federal,Rockville MD,Nuclear regulator
2,National Science Foundation NSF,Executive Branch,Various,Director,Federal,Alexandria VA,Science foundation
2,National Aeronautics and Space Administration NASA,Executive Branch,Bill Nelson (former),Administrator,Federal,Washington DC,Space agency
2,General Services Administration GSA,Executive Branch,Edward Forst,Administrator,Federal,Washington DC,Federal property management
2,Small Business Administration SBA,Executive Branch,Isabel Guzman (former),Administrator,Federal,Washington DC,Small business
3,NASA Jet Propulsion Laboratory JPL,FFRDC,Various,Director,Federal,Pasadena CA,NASA JPL
3,National Nuclear Security Administration NNSA,Department of Energy,Brandon M. Williams,Under Secretary,Federal,Washington DC,Nuclear security
3,ARPA-E,Department of Energy,Conner Prochaska,Director,Federal,Washington DC,Energy research
3,Office of Science,Department of Energy,Dr. Dar\xEDo Gil,Under Secretary for Science,Federal,Washington DC,DOE science
3,Bureau of Industry and Security BIS,Department of Commerce,Jeffrey Kessler,Under Secretary,Federal,Washington DC,Export controls
3,National Institute of Standards and Technology NIST,Department of Commerce,Arvind Raman,Under Secretary and Director,Federal,Gaithersburg MD,Standards and tech
3,Patent and Trademark Office USPTO,Department of Commerce,John A. Squires,Under Secretary and Director,Federal,Alexandria VA,Patents
3,National Oceanic and Atmospheric Administration NOAA,Department of Commerce,Dr. Neil Jacobs,Under Secretary,Federal,Silver Spring MD,NOAA
3,International Trade Administration ITA,Department of Commerce,William Kimmitt,Under Secretary,Federal,Washington DC,Trade promotion
3,Office of Space Commerce,Department of Commerce,Taylor Jordan,Assistant Secretary,Federal,Washington DC,Space commerce
3,Bureau of Economic Analysis BEA,Department of Commerce,Vipin Arora,Director,Federal,Suitland MD,Economic analysis
3,Economic Development Administration EDA,Department of Commerce,Ben Page,Deputy Assistant Secretary,Federal,Washington DC,Economic development
3,Office of Foreign Investment and National Security,Department of Energy,Michael Hein,Deputy Director,Federal,Washington DC,CFIUS
3,Federal Risk and Authorization Management Program FedRAMP,GSA,Pete Waterman,Director,Federal,Washington DC,Cloud security
3,Technology Modernization Fund,GSA,Jessie Posilkin,Acting Executive Director,Federal,Washington DC,Tech modernization
6,Office of the Secretary of the Navy,Department of the Navy,Hung Cao,Acting Secretary,DoN,Pentagon,Navy civilian leadership
6,Naval Inspector General,Department of the Navy,VADM Wayne Mouse Baze,Inspector General,DoN,Washington Navy Yard DC,Navy IG
6,Judge Advocate Generals Corps JAG,Department of the Navy,MG David J. Bligh,Judge Advocate General,DoN,Washington Navy Yard DC,Navy legal
6,Office of Small Business Programs,Department of the Navy,Andrew Magliochetti SES,Director,DoN,Washington Navy Yard DC,Navy small business
6,Chief of Naval Operations CNO,Department of the Navy,ADM Daryl Caudle,CNO,DoN,Pentagon,Highest ranking Navy officer
6,Vice Chief of Naval Operations,Department of the Navy,ADM James W. Kilby,Vice CNO,DoN,Pentagon,Second highest Navy officer
6,ASN Manpower and Reserve Affairs,Department of the Navy,Ben Kohlmann,Assistant Secretary,DoN,Pentagon,Navy personnel
6,ASN Energy Installations and Environment,Department of the Navy,Brendan P. Rogers,Assistant Secretary,DoN,Pentagon,Navy installations
6,ASN Research Development and Acquisition ASN RD&A,Department of the Navy,William Mahan,Performing Duties,DoN,Pentagon,Navy acquisition
6,Office of Naval Research ONR,ASN RD&A,Dr Rachel Riley,Chief of Naval Research,DoN,Arlington VA,Navy research
6,Naval Research Laboratory NRL,Office of Naval Research,CAPT Randy C. Cruz,Commanding Officer,DoN,Washington DC,Naval research lab
6,OPNAV N1 Manpower Personnel Training,Chief of Naval Operations,VADM Jeffrey J. Czerewko,Chief of Naval Personnel,DoN,Pentagon,Navy manpower
6,OPNAV N2/N6 Information Warfare,Chief of Naval Operations,Steve Pardoe,Director,DoN,Pentagon,Navy information warfare
6,OPNAV N3/N5/N7 Operations Plans,Chief of Naval Operations,VADM Yvette M. Davids,Deputy Chief,DoN,Pentagon,Navy operations and plans
6,OPNAV N4 Installations Logistics,Chief of Naval Operations,VADM Jeffrey T. Jablon,Deputy Chief,DoN,Pentagon,Navy logistics
6,OPNAV N8 Capabilities Resources,Chief of Naval Operations,VADM John B. Brad Skillman,Deputy Chief,DoN,Pentagon,Navy capabilities and resources
6,OPNAV N9 Warfare Requirements,Chief of Naval Operations,VADM James Pitts,Deputy Chief,DoN,Pentagon,Navy warfare requirements
6,U.S. Fleet Forces Command USFF,Chief of Naval Operations,VADM Karl Thomas,Commander,DoN,Norfolk VA,Atlantic fleet forces
6,U.S. Pacific Fleet USPACFLT,Chief of Naval Operations,ADM Stephen Web Koehler,Commander,DoN,Pearl Harbor HI,Pacific fleet
6,7th Fleet,U.S. Pacific Fleet USPACFLT,VADM Patrick J. Hannifin,Commander,DoN,Yokosuka Japan,Western Pacific
6,3rd Fleet,U.S. Pacific Fleet USPACFLT,Vacant,Commander,DoN,San Diego CA,Eastern Pacific
6,2nd Fleet,U.S. Fleet Forces Command USFF,VADM Doug Perry,Commander,DoN,Norfolk VA,Atlantic defense
6,Naval Air Forces CNAF,Chief of Naval Operations,VADM Douglas Verissimo,Commander,DoN,San Diego CA,Naval aviation
6,Naval Information Forces NAVIFOR,Chief of Naval Operations,VADM Michael Vernazza,Commander,DoN,Virginia Beach VA,Information warfare
6,Navy Expeditionary Combat Command NECC,Chief of Naval Operations,RADM Bradley Andros,Commander,DoN,Virginia Beach VA,Expeditionary forces
6,Military Sealift Command MSC,U.S. Fleet Forces Command,Various,Commander,DoN,Washington Navy Yard DC,Sealift command
6,Office of Warfighting Acceleration,Department of the Navy,Various,Director,DoN,Multiple,Accelerates capability delivery
6,Naval Rapid Capabilities Office NAVRCO,Department of the Navy,VADM Seiko Okano,Director,DoN,Washington DC,Navy rapid capabilities
6,NavalX,Naval Rapid Capabilities Office,Various,Director,DoN,Multiple,Navy innovation hub
6,Naval Air Systems Command NAVAIR,ASN RD&A,VADM John Dougherty IV,Commander,DoN,Patuxent River MD,Naval aviation acquisition
6,Naval Sea Systems Command NAVSEA,ASN RD&A,VADM James P. Downey,Commander,DoN,Washington Navy Yard DC,Naval sea systems
6,Naval Information Warfare Systems Command NAVWAR,ASN RD&A,RADM Kurt J. Rothenhaus,Commander,DoN,San Diego CA,Naval information warfare
6,Naval Facilities Engineering Systems Command NAVFAC,ASN RD&A,Various,Commander,DoN,Washington Navy Yard DC,Naval facilities
6,Naval Supply Systems Command NAVSUP,ASN RD&A,Various,Commander,DoN,Mechanicsburg PA,Naval supply
6,Strategic Systems Programs SSP,ASN RD&A,RADM Douglas Williams,Director,DoN,Washington Navy Yard DC,Strategic weapons systems
6,Naval Nuclear Propulsion Program,Department of the Navy,ADM William Houston,Director,DoN,Washington Navy Yard DC,Naval nuclear propulsion
6,PAE Maritime,ASN RD&A,Chris Miller SES,Portfolio Acquisition Executive,DoN,Washington Navy Yard DC,Surface ships and shipyards
6,PAE Undersea,ASN RD&A,VADM Robert Gaucher,Portfolio Acquisition Executive,DoN,Washington Navy Yard DC,Submarines
6,PAE Strategic Systems,ASN RD&A,VADM Johnny Wolfe,Portfolio Acquisition Executive,DoN,Washington Navy Yard DC,Strategic weapons
6,PAE Industrial Operations,ASN RD&A,VADM James Downey,Portfolio Acquisition Executive,DoN,Washington Navy Yard DC,Shipyard operations
6,PAE Aviation,ASN RD&A,VADM John Dougherty,Portfolio Acquisition Executive,DoN,Patuxent River MD,Naval aviation acquisition
6,PAE Mission Systems,ASN RD&A,Jim Day,Portfolio Acquisition Executive,DoN,San Diego CA,Mission systems
6,PAE Munitions,ASN RD&A,Paul Mann,Interim Portfolio Acquisition Executive,DoN,Patuxent River MD,Weapons and munitions
6,PAE Robotics and Autonomous Systems,ASN RD&A,Rebecca Gassler SES,Portfolio Acquisition Executive,DoN,Washington DC,RAS programs
6,Marine Corps Headquarters,Commandant of the Marine Corps,GEN Eric M. Smith,Commandant,DoN,Pentagon,Top Marine Corps leadership
6,Assistant Commandant of the Marine Corps,Marine Corps Headquarters,GEN Bradford Gering,Assistant Commandant,DoN,Pentagon,Second highest Marine
6,Director Marine Corps Staff DMCS,Marine Corps Headquarters,LTG Paul J. Rock,Director,DoN,Pentagon,Marine Corps staff director
6,Deputy Commandant Manpower and Reserve Affairs,Marine Corps Headquarters,LTG William J. Bowers,Deputy Commandant,DoN,Pentagon,Marine manpower
6,Deputy Commandant Aviation,Marine Corps Headquarters,LTG William Swan,Deputy Commandant,DoN,Pentagon,Marine aviation
6,Deputy Commandant Plans Policies Operations PP&O,Marine Corps Headquarters,LTG Jay M. Bargeron Jr.,Deputy Commandant,DoN,Pentagon,Marine plans and operations
6,Deputy Commandant Programs and Resources,Marine Corps Headquarters,LTG James B. Wellons,Deputy Commandant,DoN,Pentagon,Marine programs
6,Deputy Commandant Installations and Logistics,Marine Corps Headquarters,LTG Stephen D. Sklenka,Deputy Commandant,DoN,Pentagon,Marine installations
6,Deputy Commandant Information,Marine Corps Headquarters,LTG Jerry Carter,Deputy Commandant,DoN,Pentagon,Marine information
6,Marine Corps Combat Development and Integration MCCDC,Marine Corps Headquarters,LTG Eric Austin,Commanding General,DoN,Quantico VA,Combat development
6,Marine Corps Warfighting Laboratory,MCCDC,BG Dustin J. Byrum,Director,DoN,Quantico VA,Warfighting experimentation
6,Marine Corps Systems Command MARCORSYSCOM,MCCDC,BG Tamara Campbell,Commander,DoN,Quantico VA,Marine systems acquisition
6,PAE Marine Corps,MCCDC,LTG Eric Austin,Portfolio Acquisition Executive,DoN,Quantico VA,Marine Corps acquisition
6,Marine Corps Training Command,MCCDC,MG Michael A. Brooks,Commanding General,DoN,Quantico VA,Marine training
6,Marine Corps Recruiting Command,MCCDC,MG Walker M. Field,Commanding General,DoN,Quantico VA,Marine recruiting
6,Training and Education Command EDCOM,Marine Corps Headquarters,LTG Benjamin T. Watson,Commanding General,DoN,Quantico VA,Marine education
6,Marine Forces Reserve MARFORRES,Marine Corps Headquarters,LTG Leonard F. Anderson IV,Commander,DoN,New Orleans LA,Marine Reserve
6,Marine Forces Pacific MARFORPAC,Marine Corps Headquarters,LTG James Glynn,Commander,DoN,Camp H.M. Smith HI,Marine Pacific
6,Marine Forces Europe and Africa MARFOREUR/AF,Marine Corps Headquarters,MG Daniel Shipley,Commander,DoN,Stuttgart Germany,Marine Europe/Africa
6,Marine Forces Central MARFORCENT,Marine Corps Headquarters,LTG Joseph Clearfield,Commander,DoN,MacDill AFB FL,Marine Central
6,Marine Forces North MARFORNORTH,Marine Corps Headquarters,LTG Roberta L. Shea,Commander,DoN,Norfolk VA,Marine North
6,Marine Forces South MARFORSOUTH,Marine Corps Headquarters,LTG Len Loni Anderson,Commander,DoN,Miami FL,Marine South
6,Marine Special Operations Command MARSOC,Marine Corps Headquarters,MG Peter D. Huntley,Commander,DoN,Camp Lejeune NC,Marine special operations
6,I Marine Expeditionary Force,Marine Corps Headquarters,LTG Christian F. Wortman,Commanding General,DoN,Camp Pendleton CA,I MEF
6,II Marine Expeditionary Force,Marine Corps Headquarters,Various,Commanding General,DoN,Camp Lejeune NC,II MEF
6,III Marine Expeditionary Force,Marine Corps Headquarters,LTG Benjamin T. Watson,Commanding General,DoN,Camp Hansen Okinawa,III MEF
6,2nd Marine Division,I MEF,MG Farrell J. Sullivan,Commander,DoN,Camp Lejeune NC,2nd MarDiv
6,3rd Marine Division,III MEF,MG Kyle B. Ellison,Commander,DoN,Camp Hansen Okinawa,3rd MarDiv
6,1st Marine Aircraft Wing,III MEF,MG Robert B. Brodie,Deputy CG,DoN,Camp Hansen Okinawa,1st MAW
6,Marine Aviation Weapons and Tactics Squadron 1,Marine Corps Aviation,COL John D. Dirk,Commanding Officer,DoN,Yuma AZ,Marine aviation tactics
6,The Basic School,MCCDC,COL Robert G. McCarthy III,Commanding Officer,DoN,Quantico VA,Marine officer basic training
6,School of Infantry West,MCCDC,COL Patrick Byrne,Commanding Officer,DoN,Camp Pendleton CA,Infantry training west
6,School of Infantry East,MCCDC,COL Robert F. May,Commanding Officer,DoN,Camp Lejeune NC,Infantry training east`;
function slugify(name) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 90);
}
function sectorFromBranch(branch) {
  if (["Federal"].includes(branch)) return "Civilian";
  return "Defense";
}
function badgeFromBranch(branch) {
  const map = {
    "Army": { text: "ARMY", color: "#4a7c29" },
    "DoN": { text: "NAVY/MC", color: "#1a3a6b" },
    "Air Force": { text: "AIR FORCE", color: "#1e5fa5" },
    "Air Force/Space Force": { text: "AF/SF", color: "#1e5fa5" },
    "Space Force": { text: "SPACE FORCE", color: "#1c2951" },
    "Coast Guard": { text: "COAST GUARD", color: "#c8502d" },
    "DoW": { text: "DoW", color: "#283a6b" },
    "DoD": { text: "DoD", color: "#283a6b" },
    "All": { text: "JOINT", color: "#283a6b" },
    "Federal": { text: "FEDERAL", color: "#6b5228" }
  };
  return map[branch] ?? null;
}
function avatarColor(branch) {
  const map = {
    "Army": "#4a7c29",
    "DoN": "#1a3a6b",
    "Air Force": "#1e5fa5",
    "Air Force/Space Force": "#1e5fa5",
    "Space Force": "#1c2951",
    "Coast Guard": "#c8502d",
    "DoW": "#283a6b",
    "DoD": "#283a6b",
    "All": "#283a6b",
    "Federal": "#6b5228"
  };
  return map[branch] ?? "#283a6b";
}
function parseRows() {
  const lines = CSV.trim().split("\n").slice(1);
  return lines.map((line) => {
    const p = line.split(",");
    return {
      level: parseInt(p[0], 10),
      org: p[1]?.trim() ?? "",
      parent: p[2]?.trim() ?? "",
      leaderName: p[3]?.trim() ?? "",
      leaderTitle: p[4]?.trim() ?? "",
      branch: p[5]?.trim() ?? "",
      location: p[6]?.trim() ?? "",
      description: p[7]?.trim() ?? ""
    };
  }).filter((r) => r.org && !isNaN(r.level));
}
async function handler(req, _ctx) {
  const secret = process.env.SEED_SECRET;
  if (secret) {
    const auth = req.headers.get("Authorization") ?? "";
    if (auth !== `Bearer ${secret}`) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
  }
  const { sql: db } = (0, import_database.getDatabase)();
  const log = [];
  try {
    const rows = parseRows();
    log.push(`Parsed ${rows.length} rows`);
    await db`DELETE FROM office_members`;
    await db`DELETE FROM team_members`;
    await db`DELETE FROM offices`;
    await db`DELETE FROM teams`;
    await db`DELETE FROM followers`;
    await db`DELETE FROM contracts`;
    await db`DELETE FROM people`;
    await db`DELETE FROM related_organizations`;
    await db`DELETE FROM organization_settings`;
    await db`DELETE FROM organizations`;
    log.push("Tables cleared");
    const seen = /* @__PURE__ */ new Map();
    for (const r of rows) if (!seen.has(r.org)) seen.set(r.org, r);
    const slugCount = /* @__PURE__ */ new Map();
    const orgSlugMap = /* @__PURE__ */ new Map();
    for (const [name] of seen) {
      let slug = slugify(name);
      const n = (slugCount.get(slug) ?? 0) + 1;
      slugCount.set(slug, n);
      orgSlugMap.set(name, n > 1 ? `${slug}-${n}` : slug);
    }
    const orgIdMap = /* @__PURE__ */ new Map();
    for (const [name, row] of seen) {
      const slug = orgSlugMap.get(name);
      const badge = badgeFromBranch(row.branch);
      const [r] = await db`
        INSERT INTO organizations (name, slug, badge_text, badge_color, description, sector, hq_address)
        VALUES (${name}, ${slug}, ${badge?.text ?? null}, ${badge?.color ?? null},
                ${row.description || null}, ${sectorFromBranch(row.branch)}, ${row.location || null})
        RETURNING id
      `;
      orgIdMap.set(slug, r.id);
    }
    log.push(`Orgs inserted: ${orgIdMap.size}`);
    let relCount = 0;
    const skipParents = /* @__PURE__ */ new Set(["Executive Branch", "White House", "Congress", "Department of Homeland Security", "FFRDC", "ASD Sustainment", "ASD ND-CBD", "USD I&S", "USD P&R", "USD A&S", "USD R&E", "USD Comptroller", "OUSD R&E", "Commandant of the Marine Corps", "Marine Corps Aviation", "Direct Reporting to DepSecWar", "SOCOM Acquisition", "Coast Guard Headquarters", "Army Combined Arms Command", "Army Pathway for Innovation and Technology", "ASA ALT", "Army Corps of Engineers", "I MEF", "III MEF", "XVIII Airborne Corps", "U.S. Army Pacific", "U.S. Army Europe and Africa", "U.S. Army Western Hemisphere Command", "SAF AQ", "Air Force Life Cycle Management Center", "Combat Forces Command", "Space Training and Readiness Command", "Space Systems Command", "DEVCOM", "Army Materiel Command", "Army Transformation and Training Command", "Army Fuze", "Army FUZE", "Army University", "Army Special Operations Command", "U.S. Pacific Fleet", "U.S. Pacific Fleet USPACFLT", "U.S. Fleet Forces Command", "U.S. Fleet Forces Command USFF", "Naval Rapid Capabilities Office", "ASN RD&A", "Office of Naval Research", "MCCDC", "Marine Corps Headquarters", "Chief of Naval Operations", "Office of the Secretary of the Army", "Department of the Army", "Department of the Navy", "Department of the Air Force", "United States Space Force", "Joint Chiefs", "OSW", "Combatant Commands", "U.S. Central Command", "U.S. Africa Command", "U.S. European Command", "U.S. Indo-Pacific Command", "U.S. Northern Command", "U.S. Southern Command", "U.S. Space Command", "U.S. Special Operations Command", "U.S. Transportation Command", "U.S. Strategic Command", "U.S. Cyber Command", "SOCOM", "Air Force Chief of Staff", "Air Force Materiel Command", "Air Education and Training Command", "Air Combat Command", "Air Force Global Strike Command", "Pacific Air Forces", "U.S. Air Forces in Europe", "Chief of Space Operations", "Coast Guard Systems", "Army Materiel Command"]);
    for (const [name, row] of seen) {
      if (skipParents.has(row.parent)) continue;
      const childSlug = orgSlugMap.get(name);
      const parentSlug = orgSlugMap.get(row.parent);
      if (!childSlug || !parentSlug) continue;
      const cId = orgIdMap.get(childSlug);
      const pId = orgIdMap.get(parentSlug);
      if (!cId || !pId || cId === pId) continue;
      const [a, b] = [cId, pId].sort();
      try {
        await db`INSERT INTO related_organizations (org_id_1, org_id_2) VALUES (${a}, ${b}) ON CONFLICT DO NOTHING`;
        relCount++;
      } catch {
      }
    }
    log.push(`Relationships inserted: ${relCount}`);
    const personKeys = /* @__PURE__ */ new Set();
    let personCount = 0;
    const skip = /* @__PURE__ */ new Set(["Various", "Varies", "Vacant", "Various (Various)"]);
    for (const row of rows) {
      if (!row.leaderName || skip.has(row.leaderName)) continue;
      const orgSlug = orgSlugMap.get(row.org);
      if (!orgSlug) continue;
      const orgId = orgIdMap.get(orgSlug);
      if (!orgId) continue;
      const key = `${row.leaderName}|${orgSlug}`;
      if (personKeys.has(key)) continue;
      personKeys.add(key);
      await db`
        INSERT INTO people (org_id, full_name, role_title, avatar_color, location)
        VALUES (${orgId}, ${row.leaderName}, ${row.leaderTitle || null}, ${avatarColor(row.branch)}, ${row.location || null})
        ON CONFLICT DO NOTHING
      `;
      personCount++;
    }
    log.push(`People inserted: ${personCount}`);
    return Response.json({ ok: true, log });
  } catch (err) {
    console.error("Seed error:", err);
    return Response.json({ ok: false, error: err.message, log }, { status: 500 });
  }
}
