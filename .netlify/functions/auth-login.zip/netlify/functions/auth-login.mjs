
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/auth-login.mjs
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

// netlify/functions/lib/db.mjs
import pg from "pg";
var { Pool } = pg;
var pool;
function getDb() {
  if (!pool) {
    pool = new Pool({ connectionString: process.env.NETLIFY_DATABASE_URL || process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });
  }
  return pool;
}
async function query(text, params) {
  const db = getDb();
  const res = await db.query(text, params);
  return res.rows;
}

// netlify/functions/auth-login.mjs
var auth_login_default = async (req) => {
  try {
    const { email, password } = await req.json();
    const rows = await query("SELECT * FROM users WHERE email = $1", [email]);
    const user = rows[0];
    if (!user || !await bcrypt.compare(password, user.password_hash)) {
      return Response.json({ error: "Invalid email or password" }, { status: 401 });
    }
    await query("UPDATE users SET last_login = NOW() WHERE id = $1", [user.id]);
    const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, { expiresIn: "7d" });
    return Response.json({ token, user: { id: user.id, email: user.email, full_name: user.full_name } });
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
};
var config = { path: "/api/auth/login" };
export {
  config,
  auth_login_default as default
};
